from flask import Flask, request, jsonify
from flask_cors import CORS
import boto3

app = Flask(__name__)
CORS(app)

dynamodb = boto3.resource('dynamodb', region_name="us-east-1")
table = dynamodb.Table('UserSignups')

# ✅ Add a default route to avoid 404
@app.route("/", methods=["GET"])
def home():
    return jsonify({"message": "Flask API is running!"})

@app.route('/submit', methods=['POST'])
def submit():
    data = request.json
    response = table.put_item(Item=data)
    return jsonify({"message": "Signup successful", "response": response})

if __name__ == "__main__":
    app.run(debug=True, port=5000)

from flask import Flask, request, jsonify
import boto3
import os

app = Flask(__name__)

dynamodb = boto3.resource('dynamodb', region_name=os.getenv('AWS_REGION'))
table = dynamodb.Table('UserSignups')

@app.route('/submit', methods=['POST'])
def submit():
    data = request.json
    response = table.put_item(Item=data)
    return jsonify({"message": "Signup successful", "response": response})

if __name__ == "__main__":
    app.run(debug=True)
